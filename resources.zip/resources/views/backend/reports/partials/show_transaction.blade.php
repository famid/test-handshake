<table class="table table-bordered aiz-table mb-0">
    <tbody>
        <tr>
            <th>User Name</th>
            <td>Sakib Hossain</td>
        </tr>
        <tr>
            <th>Transaction ID</th>
            <td>asdasdasdasda</td>
        </tr>
        <tr>
            <th>Transaction Type</th>
            <td>customer_package_payment</td>
        </tr>
        <tr>
            <th>Transaction Amount</th>
            <td></td>
        </tr>
        <tr>
            <th>Gateway</th>
            <td></td>
        </tr>
        <tr>
            <th>Payment Type</th>
            <td></td>
        </tr>
        <tr>
            <th>Bank Transaction ID</th>
            <td></td>
        </tr>
        <tr>
            <th>Transaction Date</th>
            <td></td>
        </tr>
        <tr>
            <th>Card Issuer</th>
            <td></td>
        </tr>
    </tbody>
</table>
